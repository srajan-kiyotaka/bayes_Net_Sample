## To Get more information about the BayesNets Class as well as its methods:
### run the following command:

import unittest
from bayesNetsSample import BayesNets

class TestHelp(unittest.TestCase):

	def test_help(self):
		help(BayesNets)

unittest.main()